class Employee:
    def __init__(self, name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary

    def info(self):
        print(f"Имя: {self.name}, Возраст: {self.age}, Зарплата: {self.salary}")

class Manager(Employee):
    def manage(self):
        print(f"{self.name} управляет командой.")

class Teacher(Employee):
    def teach(self):
        print(f"{self.name} обучает студентов.")

# Создание объектов
employees = []

while True:
    action = input("""
Выберите действие:
1. Добавить менеджера
2. Добавить учителя
3. Показать информацию о всех сотрудниках
4. Выполнить обязанности сотрудников
5. Выйти
: """)
    
    if action == "1":
        name = input("Введите имя менеджера: ")
        age = int(input("Введите возраст менеджера: "))
        salary = float(input("Введите зарплату менеджера: "))
        employees.append(Manager(name, age, salary))
    elif action == "2":
        name = input("Введите имя учителя: ")
        age = int(input("Введите возраст учителя: "))
        salary = float(input("Введите зарплату учителя: "))
        employees.append(Teacher(name, age, salary))
    elif action == "3":
        for employee in employees:
            employee.info()
    elif action == "4":
        for employee in employees:
            if isinstance(employee, Manager):
                employee.manage()
            elif isinstance(employee, Teacher):
                employee.teach()
    elif action == "5":
        break
    else:
        print("Неверная опция, попробуйте снова.")
