employees = [
    {
        "name": "Ali Valiyev",
        "salary": 2500000,
        "experience": 3 
    },
    {
        "name": "Sardor Karimov",
        "salary": 3000000,
        "experience": 5 
    },
    {
        "name": "Gulnoza Hasanova",
        "salary": 2700000,
        "experience": 4 
    },
    {
        "name": "Nodir Abdullayev",
        "salary": 2200000,
        "experience": 2 
    },
    {
        "name": "Zamira Iskandarova",
        "salary": 3200000,
        "experience": 6  
    }
]

def calculate_salary(employees):
    return sum(employee["salary"] for employee in employees)

def search_by_name(employees, name):
    result = [employee for employee in employees if name.lower() in employee["name"].lower()]
    for employee in result:
        print(employee)

while True:
    num = input("""Can you write the num
1. The sum of all workers
2. Find the worker
3. Exit
: """)
    
    if num == "1":
        print("The sum of all workers:", calculate_salary(employees))
    elif num == "2":
        work = input("Write the name of the worker: ")
        print("Workers found:")
        search_by_name(employees, work)
    elif num == "3":
        break
    else:
        print("Not a valid option, please try again.")
