def count_palindromes(words):
    def is_palindrome(word):
        word = word.lower() 
        return word == word[::-1]

    return sum(is_palindrome(word) for word in words)

words = ["Salom", "istak", "katak", "hassa", "Mackbook", "aSsa"]
print(count_palindromes(words))