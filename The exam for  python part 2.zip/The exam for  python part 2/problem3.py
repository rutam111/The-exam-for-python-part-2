class Store:
    def __init__(self, name, location, products=None):
        self.name = name
        self.location = location
        self.products = products if products is not None else []

    def add_product(self, product):
        self.products.append(product)

    def remove_product(self, product):
        if product in self.products:
            self.products.remove(product)
        else:
            print(f"Product '{product}' not found in the store.")

    def display_products(self):
        print(f"Current products in the store '{self.name}':")
        for product in self.products:
            print(f"- {product}")

store_name = input("Enter the store name: ")
store_location = input("Enter the store location: ")
store = Store(store_name, store_location)

while True:
    action = input("""
Choose an action:
1. Add a product
2. Remove a product
3. Display products
4. Exit
: """)
    
    if action == "1":
        product_to_add = input("Enter the name of the product to add: ")
        store.add_product(product_to_add)
    elif action == "2":
        product_to_remove = input("Enter the name of the product to remove: ")
        store.remove_product(product_to_remove)
    elif action == "3":
        store.display_products()
    elif action == "4":
        break
    else:
        print("Invalid option, please try again.")
